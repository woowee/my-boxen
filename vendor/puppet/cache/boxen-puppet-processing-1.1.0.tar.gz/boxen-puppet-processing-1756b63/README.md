# Processing Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-processing.png?branch=master)](https://travis-ci.org/boxen/puppet-processing)

## Usage

```puppet
include processing
```

## Required Puppet Modules

* boxen
* stdlib
